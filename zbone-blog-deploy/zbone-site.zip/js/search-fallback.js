/* search-fallback.js — pagefind 降级搜索。
 *
 * 触发条件（见 layouts/_default/search.html）：pagefind-ui.js 加载失败
 * （flaky 主机 403，search-check 第 88 次实证可用率约 90%）、PagefindUI
 * 未定义、或构造抛异常。此时页面改用本文件做客户端搜索。
 *
 * 匹配策略：无分词子串匹配。中文不需要分词器（对比 docusaurus-search-local
 * 为中文引入 lunr-languages zh 插件的重量方案），且天然支持跨词子串
 * （如"段简"命中"手段简介"—— pagefind extended 也做不到，上游 #987 open）。
 * 多 token 为 AND 语义；打分 title×3 > tags×2 > 摘要/描述×1。
 *
 * 纯函数 search()/tokenize() 可在 node 下单测（tests/search-fallback-test.sh）；
 * mount() 只做 DOM 渲染，所有插入经 esc() 转义防 XSS。
 */
(function (global) {
  'use strict';

  function norm(s) {
    return String(s == null ? '' : s).toLowerCase();
  }

  function tokenize(q) {
    return norm(q).split(/[\s\u3000]+/).filter(function (t) { return t.length > 0; });
  }

  function snippetFor(entry, tokens) {
    var hay = norm((entry.excerpt || '') + ' ' + (entry.description || ''));
    var best = -1;
    for (var i = 0; i < tokens.length; i++) {
      var p = hay.indexOf(tokens[i]);
      if (p !== -1 && (best === -1 || p < best)) best = p;
    }
    if (best === -1) return (entry.excerpt || '').slice(0, 120);
    var text = (entry.excerpt || '') + ' ' + (entry.description || '');
    var start = Math.max(0, best - 40), end = Math.min(text.length, best + 80);
    var s = text.slice(start, end);
    if (start > 0) s = '…' + s;
    if (end < text.length) s = s + '…';
    return s;
  }

  function search(index, query, opts) {
    opts = opts || {};
    var limit = opts.limit || 10;
    var tokens = tokenize(query);
    if (tokens.length === 0 || !Array.isArray(index)) return [];
    var out = [];
    for (var i = 0; i < index.length; i++) {
      var e = index[i] || {};
      var title = norm(e.title);
      var tags = (e.tags || []).map(norm).join(' ');
      var body = norm((e.excerpt || '') + ' ' + (e.description || ''));
      var score = 0, ok = true;
      for (var t = 0; t < tokens.length; t++) {
        var tok = tokens[t];
        if (title.indexOf(tok) !== -1) { score += 3; }
        else if (tags.indexOf(tok) !== -1) { score += 2; }
        else if (body.indexOf(tok) !== -1) { score += 1; }
        else { ok = false; break; }
      }
      if (ok) out.push({ entry: e, score: score, pos: i });
    }
    out.sort(function (a, b) { return (b.score - a.score) || (a.pos - b.pos); });
    return out.slice(0, limit).map(function (r) {
      return {
        title: r.entry.title, url: r.entry.url, date: r.entry.date,
        score: r.score, snippet: snippetFor(r.entry, tokens)
      };
    });
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function renderHit(h) {
    return '<article class="sf-hit"><a href="' + esc(h.url) + '">' + esc(h.title) +
      '</a><p>' + esc(h.snippet) + '</p></article>';
  }

  function mount(el, opts) {
    opts = opts || {};
    var indexUrl = opts.indexUrl || '/search-index.json';
    var placeholder = opts.placeholder || '输入关键词搜索…';
    el.innerHTML =
      '<p class="sf-note">全文搜索暂时不可用，已切换为标题/摘要匹配（降级模式）。</p>' +
      '<input class="sf-input" type="search" placeholder="' + esc(placeholder) +
      '" aria-label="搜索文章">' +
      '<div class="sf-results" aria-live="polite"></div>';
    var input = el.querySelector('.sf-input');
    var box = el.querySelector('.sf-results');
    var index = null, failed = false;
    // no-cache：索引随每次部署更新，搜索页内抓取宁可回源（deploy-watch #11 教训）
    fetch(indexUrl, { cache: 'no-cache' }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (j) { index = j; })
      .catch(function () {
        failed = true;
        box.innerHTML = '<p class="sf-error">搜索索引加载失败，请稍后重试。</p>';
      });
    input.addEventListener('input', function () {
      var q = input.value;
      if (failed) return;
      if (!index) { box.innerHTML = q.trim() ? '<p class="sf-hint">索引加载中…</p>' : ''; return; }
      if (!q.trim()) { box.innerHTML = ''; return; }
      var hits = search(index, q, { limit: 10 });
      box.innerHTML = hits.length
        ? hits.map(renderHit).join('')
        : '<p class="sf-empty">没有找到相关文章，换个关键词试试。</p>';
    });
  }

  var api = { search: search, mount: mount, tokenize: tokenize, _esc: esc };
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    global.SearchFallback = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
